(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/1eze_next_dist_compiled_1cda2qy._.js","static/chunks/1eze_next_dist_shared_lib_0_-rlb6._.js","static/chunks/1eze_next_dist_client_0q4bu6h._.js","static/chunks/1eze_next_dist_0uesjbk._.js","static/chunks/[next]_entry_page-loader_ts_0l1b95s._.js","static/chunks/1eze_react-dom_1e446jx._.js","static/chunks/1eze_01tc1f-._.js","static/chunks/[root-of-the-server]__0tlzug0._.js"],
    source: "entry"
});
