(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/1eze_next_dist_compiled_1cda2qy._.js","static/chunks/1eze_next_dist_shared_lib_1tkbqk6._.js","static/chunks/1eze_next_dist_client_0q4bu6h._.js","static/chunks/1eze_next_dist_0wixqw-._.js","static/chunks/1eze_next_app_1388bf7.js","static/chunks/[next]_entry_page-loader_ts_212xcgv._.js","static/chunks/1eze_react-dom_1e446jx._.js","static/chunks/1eze_01tc1f-._.js","static/chunks/[root-of-the-server]__164v7jc._.js"],
    source: "entry"
});
