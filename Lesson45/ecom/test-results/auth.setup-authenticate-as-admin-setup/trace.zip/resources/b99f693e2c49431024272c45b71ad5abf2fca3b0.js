(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1muri2o._.js","static/chunks/1eze_next_dist_compiled_next-devtools_index_19lakkm.js","static/chunks/1eze_next_dist_compiled_react-dom_108i41g._.js","static/chunks/1eze_next_dist_compiled_react-server-dom-turbopack_0oy5yzz._.js","static/chunks/1eze_next_dist_compiled_1f_-dm9._.js","static/chunks/1eze_next_dist_client_0dzugd5._.js","static/chunks/1eze_next_dist_0s-z44u._.js","static/chunks/1eze_@swc_helpers_cjs_1mdmjnb._.js"],
    source: "entry"
});
