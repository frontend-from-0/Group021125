(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__083ifbz._.css","static/chunks/1eze_0m9vvfc._.js","static/chunks/Lesson45_ecom_src_0we-vu8._.js"],
    source: "dynamic"
});
