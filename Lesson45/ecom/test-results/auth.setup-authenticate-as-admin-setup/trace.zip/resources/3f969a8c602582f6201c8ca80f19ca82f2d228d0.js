(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/Lesson45_ecom_src_components_ui_table_tsx_1tc1zqm._.js"],
    source: "dynamic"
});
