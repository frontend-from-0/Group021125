(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/1eze_03lkwh-._.js","static/chunks/Lesson45_ecom_src_0upacp0._.js"],
    source: "dynamic"
});
