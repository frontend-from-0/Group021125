(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/1eze_next_dist_11fbtxw._.js","static/chunks/Lesson45_ecom_src_components_ui_table_tsx_1tc1zqm._.js"],
    source: "dynamic"
});
